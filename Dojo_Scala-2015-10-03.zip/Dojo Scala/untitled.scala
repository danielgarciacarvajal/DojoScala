object dojo{
	def main(args: Array[String]){
	var sum1= readLine()
	var sum2 = readLine()
	var suma = suma(sum1,sum2)
	print("suma  "+ suma)
	}
	def suma(x:int,y:int)=x+y
	
}